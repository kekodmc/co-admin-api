/*
Navicat MySQL Data Transfer

Source Server         : local_linux
Source Server Version : 80017
Source Host           : 127.0.0.1:3306
Source Database       : chat

Target Server Type    : MYSQL
Target Server Version : 80017
File Encoding         : 65001

Date: 2020-12-08 17:41:44
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `role_id` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `token` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `login_time` int(11) DEFAULT '0',
  `avatar` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '头像',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('1', 'admin', '$2y$10$UDuUWPTQ8vGZRhS5SjCgMuNf5Up175iUZD/XRo.54UVRhDdPYhQE.', '1', '1', '1606706542', '1607413991', 'LKwXJod4ee1f033c50a2d4c65ce9cee8', '1607413991', 'http://chat.test.cn/uploads/20201207/15fcde9a6c2a1f712.jpeg');
INSERT INTO `admin` VALUES ('2', 'zs', '$2y$10$3lUm7u.sDA8.ukHAVMjGduJUsgUTpv1o6N5K8IpmOtQ065jnv6GX.', '2', '0', '1606706542', '1607391858', '', '1606898385', 'http://chat.test.cn/avatar.jpg');

-- ----------------------------
-- Table structure for config
-- ----------------------------
DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `value` text COLLATE utf8mb4_general_ci,
  `type` tinyint(4) DEFAULT '0',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `remark` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`,`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of config
-- ----------------------------
INSERT INTO `config` VALUES ('2', 'notice', '<p>系统公告</p>\n<p><img src=\"http://chat.test.cn/uploads/20201203/15fc886c3f0242253.jpeg\" alt=\"\" width=\"100%\" /></p>', '0', '1606977271', '1607414139', null);

-- ----------------------------
-- Table structure for power
-- ----------------------------
DROP TABLE IF EXISTS `power`;
CREATE TABLE `power` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `controller` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `action` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT '0',
  `status` tinyint(4) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `url` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `sort` int(11) DEFAULT '1',
  `type` tinyint(4) DEFAULT '0' COMMENT '1模块，0权限',
  `delete_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of power
-- ----------------------------
INSERT INTO `power` VALUES ('1', null, '', '', '0', '1', '1606531337', '1606531337', null, '管理员', '2', '1', '0');
INSERT INTO `power` VALUES ('2', null, 'admin', 'index', '1', '1', '1606532252', '1606532252', 'admin-index', '管理员列表', '1', '0', '0');
INSERT INTO `power` VALUES ('3', null, 'power', 'index', '1', '1', '1606533529', '1606533529', 'power-index', '权限列表', '13', '0', '0');
INSERT INTO `power` VALUES ('4', null, 'power', 'save', '1', '1', '1606533606', '1606708431', 'power-save', '权限添加', '16', '0', '0');
INSERT INTO `power` VALUES ('5', null, null, null, '0', '1', '1606544358', '1606544358', null, '系统设置', '10', '1', '0');
INSERT INTO `power` VALUES ('6', null, 'role', 'index', '1', '1', '1606552256', '1606552256', 'role-index', '角色列表', '7', '0', '0');
INSERT INTO `power` VALUES ('7', null, 'role', 'save', '1', '1', '1606552283', '1606552283', 'role-save', '角色添加', '10', '0', '0');
INSERT INTO `power` VALUES ('8', null, 'admin', 'save', '1', '1', '1606556904', '1606556904', 'admin-save', '管理员添加', '4', '0', '0');
INSERT INTO `power` VALUES ('9', null, 'admin', 'update', '1', '1', '1606556927', '1606556927', 'admin-update', '管理员编辑', '5', '0', '0');
INSERT INTO `power` VALUES ('10', null, 'role', 'update', '1', '1', '1606557066', '1606557066', 'role-update', '角色编辑', '11', '0', '0');
INSERT INTO `power` VALUES ('11', null, 'power', 'update', '1', '1', '1606557081', '1606557081', 'power-update', '权限编辑', '17', '0', '0');
INSERT INTO `power` VALUES ('12', null, 'admin', 'role', '1', '1', '1606705665', '1606705665', 'admin-role', '管理员角色', '3', '0', '0');
INSERT INTO `power` VALUES ('13', null, 'role', 'power', '1', '1', '1606707095', '1606707095', 'role-power', '角色权限', '9', '0', '0');
INSERT INTO `power` VALUES ('14', null, 'power', 'mod', '1', '1', '1606717343', '1606717343', 'power-mod', '权限模块', '15', '0', '0');
INSERT INTO `power` VALUES ('15', null, 'power', 'read', '1', '1', '1606717548', '1606717548', 'power-read', '权限详情', '14', '0', '0');
INSERT INTO `power` VALUES ('16', null, 'role', 'read', '1', '1', '1606717606', '1606717606', 'role-read', '角色详情', '8', '0', '0');
INSERT INTO `power` VALUES ('17', null, 'admin', 'read', '1', '1', '1606717741', '1606717741', 'admin-read', '管理员详情', '2', '0', '0');
INSERT INTO `power` VALUES ('18', null, 'power', 'delete', '1', '1', '1606727420', '1606727692', 'power-delete', '权限删除', '18', '0', '0');
INSERT INTO `power` VALUES ('19', null, 'role', 'delete', '1', '1', '1606729337', '1606729337', 'role-delete', '角色删除', '12', '0', '0');
INSERT INTO `power` VALUES ('20', null, 'admin', 'delete', '1', '1', '1606729354', '1606729354', 'admin-delete', '管理员删除', '6', '0', '0');
INSERT INTO `power` VALUES ('21', null, '', '', '0', '1', '1606730798', '1606730845', '', '主页', '1', '1', '0');
INSERT INTO `power` VALUES ('22', null, 'index', 'index', '21', '1', '1606730878', '1606730946', 'index-index', '概览', '1', '0', '0');
INSERT INTO `power` VALUES ('23', null, 'upload', 'index', '5', '1', '1606819677', '1606819677', 'upload-index', '上传文件', '1', '0', '0');
INSERT INTO `power` VALUES ('24', null, 'admin', 'disable', '1', '1', '1606898226', '1606898226', 'admin-disable', '启用/禁用账户', '1', '0', '0');
INSERT INTO `power` VALUES ('25', null, 'setting', 'getNotice', '5', '1', '1606976198', '1606976218', 'setting-getNotice', '获取公告', '1', '0', '0');
INSERT INTO `power` VALUES ('26', null, 'setting', 'setNotice', '5', '1', '1606976255', '1606976255', 'setting-setNotice', '保存公告', '1', '0', '0');

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `power_id` text COLLATE utf8mb4_general_ci,
  `status` tinyint(4) DEFAULT NULL,
  `create_time` int(11) DEFAULT '0',
  `update_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES ('1', '超级管理员', '22,2,24,17,12,8,9,20,6,16,13,7,10,19,3,15,14,4,11,18,26,23,25', '1', '1606548123', '1606976274');
INSERT INTO `role` VALUES ('2', '普通管理员', '22,2,6,3', '1', '1606706220', '1606898371');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `nickname` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `create_time` int(11) DEFAULT '0',
  `update_time` int(11) DEFAULT '0',
  `token` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `login_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `nickname` (`nickname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of user
-- ----------------------------
